﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApplication5.Models
{

    [MetadataType(typeof(adminviewmodel))]
    public partial class tbl_admin
    {

    }

    [MetadataType(typeof(registrationviewmodel))]
    public partial class tbl_registration
    {

    }

    [MetadataType(typeof(enrolmentviewmodel))]
    public partial class tbl_enrolment
    {

    }
    [MetadataType(typeof(teacherviewmodel))]
    public partial class teacher
    {
    }
    [MetadataType(typeof(eventviwmodel))]
    public partial class eventss
    {
    }

    [MetadataType(typeof(janfeeviewmodel))]
    public partial class fee_Amount_January
    {

    }

    [MetadataType(typeof(febamountviewmodel))]
    public partial class fee_Amount_February
    {

    }
    [MetadataType(typeof(marfeeviemodel))]
    public partial class fee_Amount_march
    {

    }

    [MetadataType(typeof(feeaprilviewmodel))]
    public partial class fee_Amount_April
    {

    }


    [MetadataType(typeof(feemayviewmodel))]
    public partial class fee_Amount_May
    {

    }


    [MetadataType(typeof(feejuneviewmodel))]
    public partial class fee_Amount_June
    {

    }


    [MetadataType(typeof(feejulyviewmodel))]
    public partial class fee_Amount_July
    {

    }


    [MetadataType(typeof(feeaugviewmodel))]
    public partial class fee_Amount_Augest
    {

    }

    [MetadataType(typeof(feesepviewmodel))]
    public partial class fee_Amount_September
    {

    }


    [MetadataType(typeof(feeoctviewmodel))]
    public partial class fee_Amount_Octuber
    {

    }


    [MetadataType(typeof(feenovviewmodel))]
    public partial class fee_Amount_November
    {

    }


    [MetadataType(typeof(feedecviewmodel))]
    public partial class fee_Amount_December
    {

    }
    [MetadataType(typeof(playgviewmodel))]
    public partial class playgroup_courses
    {


    }

    [MetadataType(typeof(classIviewmodel))]
    public partial class classI_courses
    {


    }
    [MetadataType(typeof(classiiviewmodel))]
    public partial class classII_courses
    {


    }
    [MetadataType(typeof(classiiiviewmodel))]
    public partial class classIII_courses
    {


    }
    [MetadataType(typeof(classivviewmodel))]
    public partial class classIV_courses
    {


    }
    [MetadataType(typeof(classvviewmodel))]
    public partial class classV_courses
    {


    }
    [MetadataType(typeof(classViviewmodel))]
    public partial class VI_courses
    {


    }
    [MetadataType(typeof(classviiviewmodel))]
    public partial class VII_courses
    {


    }
    [MetadataType(typeof(classviiivewimodel))]
    public partial class VIII_courses
    {


    }
    [MetadataType(typeof(classixviewmodel))]
    public partial class IX_courses
    {


    }
    [MetadataType(typeof(classxviewmodel))]
    public partial class X_courses
    {


    }

    [MetadataType(typeof(timetableviewmodel))]
    public partial class timetable
    {


    }

    [MetadataType(typeof(attjanviewmodel))]
    public partial class atten_January
    {


    }

    [MetadataType(typeof(attenfebviewmodel))]
    public partial class atten_feb
    {


    }

    [MetadataType(typeof(attenmarchviewmodel))]
    public partial class atten_march
    {


    }

    [MetadataType(typeof(attenaprilviewmodel))]
    public partial class atten_april
    {


    }

    [MetadataType(typeof(attenmayviewmodel))]
    public partial class atten_may
    {


    }

    [MetadataType(typeof(attenjuneviewmodel))]
    public partial class atten_June
    {


    }

    [MetadataType(typeof(attenjulyviewmodel))]
    public partial class atten_July
    {


    }

    [MetadataType(typeof(atteaugviewmodel))]
    public partial class atten_aug
    {


    }

    [MetadataType(typeof(attensepviewmodel))]
    public partial class atten_sep
    {


    }


    [MetadataType(typeof(attenoctviewmodel))]
    public partial class atten_oct
    {


    }

    [MetadataType(typeof(attennovviewmodel))]
    public partial class atten_nov
    {


    }

    [MetadataType(typeof(attendecviewmodel))]
    public partial class atten_dec
    {


    }

    


}